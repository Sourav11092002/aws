import React, { useState } from 'react';
import { useTodo } from './TodoContext';

const TodoApp: React.FC = () => {
  const [input, setInput] = useState('');
  const { todos, addTodo, removeTodo, clearTodos } = useTodo();

  const handleAdd = () => {
    if (input.trim()) {
      addTodo(input);
      setInput('');
    }
  };

  return (
    <div>
      <h1>To-Do App</h1>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Add a todo"
      />
      <button onClick={handleAdd}>Add</button>
      <ul>
        {todos.map((todo, index) => (
          <li key={index}>
            {todo} <button onClick={() => removeTodo(index)}>Remove</button>
          </li>
        ))}
      </ul>
      <button onClick={clearTodos}>Delete All</button>
    </div>
  );
};

export default TodoApp;