import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
  const response = await fetch('/product.json'); 
  const data = await response.json(); // data is the actual parsed JSON
  console.log("data", data);
  return data.PRODUCTS; // ✅ Access PRODUCTS from parsed JSON
});


const productSlice = createSlice({
  name: 'products',
  initialState: {
    items: [],
  },
  reducers: {
    rateProduct: (state, action) => {
      const product = state.items.find((p) => p.name === action.payload);
      if (product) {
        product.rating += 1;
      }
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchProducts.fulfilled, (state, action) => {
      state.items = action.payload;
    });
  },
});

export const { rateProduct } = productSlice.actions;
export default productSlice.reducer;
