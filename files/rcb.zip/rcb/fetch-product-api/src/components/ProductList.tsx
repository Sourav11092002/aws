import React from 'react';
import type { Product } from '../App';

interface ProductListProps {
  products: Product[];
  onRemove: (id: number) => void;
}

const ProductList: React.FC<ProductListProps> = ({ products, onRemove }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {products.map(product => (
        <div key={product.id} className="border p-4 rounded shadow">
          <img src={product.image} alt={product.title} className="h-40 object-contain mx-auto mb-2" />
          <h2 className="font-semibold text-lg">{product.title}</h2>
          <p className="text-sm text-gray-600 mb-2">{product.description.substring(0, 100)}...</p>
          <p className="font-bold text-blue-600 mb-2">${product.price}</p>
          <button onClick={() => onRemove(product.id)} className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
            Remove
          </button>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
