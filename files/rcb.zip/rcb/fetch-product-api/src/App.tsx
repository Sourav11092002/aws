import React, { useEffect, useState } from 'react';
import ProductList from './components/ProductList';

export interface Product {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
}

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const localData = localStorage.getItem('products');
      if (localData) {
        setProducts(JSON.parse(localData));
      } else {
        const res = await fetch('https://fakestoreapi.com/products');
        const data: Product[] = await res.json();
        const electronics = data.filter(item => item.category === 'electronics');
        setProducts(electronics);
        localStorage.setItem('products', JSON.stringify(electronics));
      }
    };
    fetchData();
  }, []);

  const handleRemove = (id: number) => {
    const updated = products.filter(product => product.id !== id);
    setProducts(updated);
    localStorage.setItem('products', JSON.stringify(updated));
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Electronics Products</h1>
      <ProductList products={products} onRemove={handleRemove} />
      <div className="mt-4 text-lg">Total Products: {products.length}</div>
    </div>
  );
};

export default App;
