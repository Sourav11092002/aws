//1st question

// import React from "react";

// type ProductCardProps = {
//     image: string;
//     title: string;
//     newPrice: number;
//     oldPrice: number;
//     rating: number;
//     reviews: number;
//     description: string;
// };

// const ProductCard: React.FC<ProductCardProps> = ({
//     image,
//     title,
//     newPrice,
//     oldPrice,
//     rating,
//     reviews,
//     description, }) => {
//     return (
//         <div className="flex items-center border p-4 rounded-lg shadow-sm bg-white mb-4">
//             <img src={image} alt={title} className="w-32 h-32 object-contain mr-6" />
//             <div className="flex-1">
//                 <h2 className="font-semibold text-lg">{title}</h2>
//                 <div className="flex items-center space-x-2">
//                     <span className="text-red-600 font-bold">${newPrice.toFixed(2)}</span>
//                     <span className="line-through text-gray-500 text-sm">${oldPrice.toFixed(2)}</span>
//                 </div>

//                 <p className="text-gray-600 text-sm mt-2">
//                     {description} <strong>enim</strong>.
//                 </p>
//                 <div className="flex gap-2 mt-4">
//                     <button className="bg-red-500 text-white px-4 py-2 rounded ">
//                         Add to Cart
//                     </button>
//                     <button className="border border-red-500 text-red-500 px-4 py-2 rounded ">
//                         Wishlist
//                     </button>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default ProductCard;


// -------------------------------------------------------------------------
// 2nd Question

// import React from "react";

// const ProductCard = () => {
//     return (
//         <div className="max-w-6xl mx-auto p-6 bg-white rounded shadow-md">
//             <div className="flex flex-col md:flex-row gap-8">
//                 <div className="md:w-1/2">
//                     <img
//                         src="https://img.freepik.com/premium-psd/skincare-product-sale-poster-template_597316-411.jpg?semt=ais_hybrid&w=240"
//                         alt="Main product"
//                         className="w-100 h-100 rounded"
//                     />

//                 </div>

//                 <div className="md:w-1/2 space-y-4">
//                     <h2 className="text-2xl font-bold">MEN'S ADIDAS COURTSMASH</h2>


//                     <ul className="text-sm space-y-1">
//                         <li><span className="font-semibold">Availability:</span> <span className="text-green-600">In Stock</span></li>
//                         <li><span className="font-semibold">Brand:</span> Adidas</li>

//                     </ul>


//                     <div className="text-xl font-bold text-red-600">
//                         $45.00
//                         <span className="text-gray-400 line-through text-base ml-2">$55.00</span>
//                     </div>


//                     <div className="flex gap-4 mt-4">
//                         <button className="bg-red-500 text-white px-4 py-2 rounded">
//                             Add to Cart
//                         </button>
//                         <button className="border border-red-500 text-red-500 px-4 py-2 rounded">
//                             Wishlist
//                         </button>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default ProductCard;


// -------------------------------------------------------------------------------------------------
//3rd question

// import React from "react";

// interface ProductCardProps {
//   image: string;
//   bgcolor: string;
//   bannertext1: string;
//   bannertext2: string;
//   bannertext3: string;
//   linkurl: string;
// }

// function ProductCard(props:ProductCardProps)  {
//   return (
//     <div className={flex items-center justify-between p-6 rounded-lg ${props.bgcolor} w-full max-w-md}>
//       <div>
//         <p className="text-xs text-red-500 font-semibold">{props.bannertext1}</p>
//         <h2 className="text-lg font-bold">{props.bannertext2}</h2>
//         <p className="text-sm text-gray-600">{props.bannertext3}</p>
//         <a
//           href={props.linkurl}
//           className="inline-block mt-3 px-4 py-1 text-white bg-red-500 rounded hover:bg-red-600 text-sm"
//         >
//           SHOP NOW
//         </a>
//       </div>
//       <img src={props.image} alt="product" className="w-28 h-auto object-contain" />
//     </div>
//   );
// };

// export default ProductCard;

// ------------------------------------------------------------------------------------------------------------
//4th question


// import React, { useEffect, useState } from "react";

// type FetchApi = {
//     name: string;
//     price: number;
//     Image: string;
// };

// function ProductCard() {
//     const [Data, SetData] = useState<FetchApi[] | undefined>();

//     useEffect(() => {
//         fetch("./User.json")
//             .then((Response) => Response.json())
//             .then((data) => {
//                 console.log(data);
//                 SetData(data);
//             });
//     }, []);

//     return (
//         <div className="max-w-4xl mx-auto p-6 mt-10 bg-white rounded-2xl shadow-md">
//             <h3 className="text-2xl font-semibold mb-6 text-center text-gray-700"> Product List</h3>

//             <div className="grid grid-cols-3 font-semibold bg-gray-100 text-gray-700 px-4 py-2 rounded-t-lg">
//                 <div>Name</div>
//                 <div>Price</div>
//                 <div>Image</div>
//             </div>

//             <div className="divide-y divide-gray-200">
//                 {Data?.map((item, index) => (
//                     <div
//                         key={index}
//                         className="grid grid-cols-3 items-center px-4 py-4 hover:bg-gray-50"
//                     >
//                         <div>{item.name}</div>
//                         <div>${item.price}</div>
//                         <div>
//                             <img
//                                 src={item.Image}
//                                 alt={item.name}
//                                 className="w-20 h-20 object-cover rounded-md"
//                             />
//                         </div>
//                     </div>
//                 ))}
//             </div>
//         </div>
//     );
// }

// export default ProductCard;


// ---------------------------------------------------------

///Timer

// import React, { useState, useEffect, useRef } from 'react';

// const ProductCard: React.FC = () => {
//     const [seconds, setSeconds] = useState(0);
//     const [isRunning, setIsRunning] = useState(false);
//     const intervalRef = useRef<number | null>(null);

//     useEffect(() => {
//         if (isRunning) {
//             intervalRef.current = setInterval(() => {
//                 setSeconds((prev) => prev + 1);
//             }, 1000);
//         } else if (intervalRef.current) {
//             clearInterval(intervalRef.current);
//         }

//         return () => {
//             if (intervalRef.current) {
//                 clearInterval(intervalRef.current);
//             }
//         };
//     }, [isRunning]);

//     const startTimer = () => {
//         setIsRunning(true);
//     };

//     const stopTimer = () => {
//         setIsRunning(false);
//     };

//     const resetTimer = () => {
//         setIsRunning(false);
//         setSeconds(0);
//     };

//     const formatTime = (totalSeconds: number): string => {
//         const minutes = Math.floor(totalSeconds / 60);
//         const secs = totalSeconds % 60;
//         const paddedMinutes = String(minutes).padStart(2, '0');
//         const paddedSeconds = String(secs).padStart(2, '0');
//         return ${paddedMinutes}:${paddedSeconds};
//     };

//     return (
//         <div className="max-w-sm mx-auto mt-10 p-6 bg-white rounded-2xl shadow-lg text-center">
//             <h1 className="text-3xl font-bold mb-4 text-gray-800">
//                 Timer: {formatTime(seconds)}
//             </h1>
//             <div className="flex justify-center gap-4">
//                 <button
//                     onClick={startTimer}
//                     className="px-4 py-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition duration-200"
//                 >
//                     Start
//                 </button>
//                 <button
//                     onClick={stopTimer}
//                     className="px-4 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600 transition duration-200"
//                 >
//                     Stop
//                 </button>
//                 <button
//                     onClick={resetTimer}
//                     className="px-4 py-2 bg-yellow-500 text-white rounded-xl hover:bg-yellow-600 transition duration-200"
//                 >
//                     Reset
//                 </button>
//             </div>
//         </div>
//     );
// };

// export default ProductCard;

// --------------------------------------------------------------------------------------------------------

///Form and store details


// import React from 'react';

// const ProductCard: React.FC = () => {
//     return (
//         <div className="max-w-6xl mx-auto p-6 md:p-12 grid md:grid-cols-2 gap-10 ">
           
//             <div>
//                 <h2 className="text-xl font-bold text-gray-800 mb-2">LEAVE US A MESSAGE</h2>
//                 <p className="text-sm text-gray-600 mb-6">Use the form belllow</p>
//                 <form className="space-y-4">
//                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                         <div>
//                             <label className="block text-sm font-medium text-gray-700">First Name<span className="text-red-500">*</span></label>
//                             <input type="text" className="w-full border border-gray-300 rounded-md p-2 " />
//                         </div>
//                         <div>
//                             <label className="block text-sm font-medium text-gray-700">Last Name<span className="text-red-500">*</span></label>
//                             <input type="text" className="w-full border border-gray-300 rounded-md p-2" />
//                         </div>
//                     </div> 
//                     <div>
//                         <label className="block text-sm font-medium text-gray-700">Email Address<span className="text-red-500">*</span></label>
//                         <input type="email" className="w-full border border-gray-300 rounded-md p-2 " />
//                     </div>
//                     <div>
//                         <label className="block text-sm font-medium text-gray-700">Subject</label>
//                         <input type="text" className="w-full border border-gray-300 rounded-md p-2" />
//                     </div>
//                     <div>
//                         <label className="block text-sm font-medium text-gray-700">Your message<span className="text-red-500">*</span></label>
//                         <textarea className="w-full border border-gray-300 rounded-md p-2 " />
//                     </div>
//                     <button type="submit" className="bg-pink-400 text-white px-6 py-2 ">
//                     Send
//                     </button>
//                 </form>
//             </div>

           
//             <div className="bg-gray-50 p-6 rounded-md ">
//                 <h3 className="text-lg font-semibold text-gray-800 mb-4">OUR STORE</h3>
//                 <p className="text-sm text-gray-600 mb-2">
//                      Himachal
//                 </p>
//                 <p className="text-sm text-gray-600 mb-2">
//                      +0000000000000000000000
//                 </p>
//                 <p className="text-sm text-gray-600 mb-4">✉abc.com</p>

//                 <h4 className="font-semibold mb-2 text-gray-800">HOURS OF OPERATION</h4>
//                 <ul className="text-sm text-gray-600 mb-6">
//                     {['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'].map((day) => (
//                         <li key={day} className="flex justify-between border-b py-1">
//                             <span>{day}</span>
                            
//                         </li>
//                     ))}
//                 </ul>

//                 <h4 className="font-semibold text-gray-800 mb-1">CAREERS</h4>
//                 <p className="text-sm text-gray-600">
//                     Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, incidunt.
//                     <br />
//                     <a href="fndfjdfdjf fdfbdfnfnn  " className="text-pink-600 underline">sdfndfhfdkh</a>
//                 </p>
//             </div>
//         </div>
//     );
// };

// export default ProductCard;