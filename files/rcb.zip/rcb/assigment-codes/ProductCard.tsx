//1st question

// import React from "react";

// type ProductCardProps = {
//     image: string;
//     title: string;
//     newPrice: number;
//     oldPrice: number;
//     rating: number;
//     reviews: number;
//     description: string;
// };

// const ProductCard: React.FC<ProductCardProps> = ({
//     image,
//     title,
//     newPrice,
//     oldPrice,
//     rating,
//     reviews,
//     description, }) => {
//     return (
//         <div className="flex items-center border p-4 rounded-lg shadow-sm bg-white mb-4">
//             <img src={image} alt={title} className="w-32 h-32 object-contain mr-6" />
//             <div className="flex-1">
//                 <h2 className="font-semibold text-lg">{title}</h2>
//                 <div className="flex items-center space-x-2">
//                     <span className="text-red-600 font-bold">${newPrice.toFixed(2)}</span>
//                     <span className="line-through text-gray-500 text-sm">${oldPrice.toFixed(2)}</span>
//                 </div>

//                 <p className="text-gray-600 text-sm mt-2">
//                     {description} <strong>enim</strong>.
//                 </p>
//                 <div className="flex gap-2 mt-4">
//                     <button className="bg-red-500 text-white px-4 py-2 rounded ">
//                         Add to Cart
//                     </button>
//                     <button className="border border-red-500 text-red-500 px-4 py-2 rounded ">
//                         Wishlist
//                     </button>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default ProductCard;


// -------------------------------------------------------------------------
// 2nd Question

// import React from "react";

// const ProductCard = () => {
//     return (
//         <div className="max-w-6xl mx-auto p-6 bg-white rounded shadow-md">
//             <div className="flex flex-col md:flex-row gap-8">
//                 <div className="md:w-1/2">
//                     <img
//                         src="https://img.freepik.com/premium-psd/skincare-product-sale-poster-template_597316-411.jpg?semt=ais_hybrid&w=240"
//                         alt="Main product"
//                         className="w-100 h-100 rounded"
//                     />

//                 </div>

//                 <div className="md:w-1/2 space-y-4">
//                     <h2 className="text-2xl font-bold">MEN'S ADIDAS COURTSMASH</h2>


//                     <ul className="text-sm space-y-1">
//                         <li><span className="font-semibold">Availability:</span> <span className="text-green-600">In Stock</span></li>
//                         <li><span className="font-semibold">Brand:</span> Adidas</li>

//                     </ul>


//                     <div className="text-xl font-bold text-red-600">
//                         $45.00
//                         <span className="text-gray-400 line-through text-base ml-2">$55.00</span>
//                     </div>


//                     <div className="flex gap-4 mt-4">
//                         <button className="bg-red-500 text-white px-4 py-2 rounded">
//                             Add to Cart
//                         </button>
//                         <button className="border border-red-500 text-red-500 px-4 py-2 rounded">
//                             Wishlist
//                         </button>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default ProductCard;


// -------------------------------------------------------------------------------------------------
//3rd question

// import React from "react";

// interface ProductCardProps {
//   image: string;
//   bgcolor: string;
//   bannertext1: string;
//   bannertext2: string;
//   bannertext3: string;
//   linkurl: string;
// }

// function ProductCard(props:ProductCardProps)  {
//   return (
//     <div className={flex items-center justify-between p-6 rounded-lg ${props.bgcolor} w-full max-w-md}>
//       <div>
//         <p className="text-xs text-red-500 font-semibold">{props.bannertext1}</p>
//         <h2 className="text-lg font-bold">{props.bannertext2}</h2>
//         <p className="text-sm text-gray-600">{props.bannertext3}</p>
//         <a
//           href={props.linkurl}
//           className="inline-block mt-3 px-4 py-1 text-white bg-red-500 rounded hover:bg-red-600 text-sm"
//         >
//           SHOP NOW
//         </a>
//       </div>
//       <img src={props.image} alt="product" className="w-28 h-auto object-contain" />
//     </div>
//   );
// };

// export default ProductCard;

// ------------------------------------------------------------------------------------------------------------
//4th question



// import React, { useEffect, useState } from "react";

// type FetchApi = {
//     name: string,
//     price: number,
//     Image: string
// }

// function ProductCard() {
//     const [Data, SetData] = useState<FetchApi[] | undefined>();
//     useEffect(() => {

//         fetch("./Usser.json").then((Response) => {
//             return Response.json();
//         }).then((data) => {
//             console.log(data);
//             SetData(data);
//         })
//     }, []);
//     return (
//         <>

//             <h3>sourav</h3>
//             <table>

//                 {
//                     Data?.map((item) => {
//                         return (
//                             <div className=" flex  justify-center items-center">
//                                 <tr>
//                                     <td>{item.name}</td>
//                                     <td>{item.price}</td>
//                                     <td><img src={item.Image} /></td>
//                                 </tr>
//                             </div>
//                         )
//                     })
//                 }
//             </table>
//         </>
//     )
// }
// export default ProductCard;

// ---------------------------------------------------------

///Timer

// import React, { useState, useEffect, useRef } from 'react';

// const ProductCard: React.FC = () => {
//     const [seconds, setSeconds] = useState(0);
//     const [isRunning, setIsRunning] = useState(false);
//     const intervalRef = useRef<NodeJS.Timeout | null>(null);

//     useEffect(() => {
//         if (isRunning) {
//             intervalRef.current = setInterval(() => {
//                 setSeconds((prev) => prev + 1);
//             }, 1000);
//         } else {
//             if (intervalRef.current) {
//                 clearInterval(intervalRef.current);
//             }
//         }

//         return () => {
//             if (intervalRef.current) {
//                 clearInterval(intervalRef.current);
//             }
//         };
//     }, [isRunning]);

//     const startTimer = () => {
//         setIsRunning(true);
//     };

//     const stopTimer = () => {
//         setIsRunning(false);
//     };

//     return (
//         <div>
//             <h1>Timer: {seconds} seconds</h1>
//             <button onClick={startTimer}>Start</button>
//             <button onClick={stopTimer}>Stop</button>
//         </div>
//     );
// };

// export default ProductCard;