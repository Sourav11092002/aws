// import React from 'react';
// import logo from './logo.svg';
// import './index.css';
// import { BrowserRouter, Route, Routes } from 'react-router-dom';
// import Login from './Login';
// import Content from './Content';
// import About from './About';

// import { createBrowserRouter, RouterProvider } from "react-router-dom";
// import Prouter from "./Prouter";

// import { createBrowserRouter, RouterProvider } from "react-router-dom";
// import Login from "./Login";
// import About from "./About";

// function App() {
//   return (
//     <div>
//       <h2 className='text-red-900'>Welcome Sourav</h2>
//       <BrowserRouter>
//         <Content />
//         <Routes>
//           <Route path="/" element={<div>Hello Sourav</div>} />
//           <Route path="/login/:city" element={<Login />} />
//           <Route path="/about" element={<About />} />

//         </Routes>
//       </BrowserRouter>

//     </div>

//   );
// }

// export default App;

// -----------------------------------------------------------------------------------------------------

// import { createBrowserRouter, RouterProvider } from "react-router-dom";
// import About, { fetchData } from "./About";
// const router = createBrowserRouter([
//   {
//     path: "/",
//     element: <div>Hello Sourav</div>
//   },
//   {
//     path: "/about",
//     element: <About />,
//     loader: fetchData
//     // Example loader function
//   }
// ])
// const App = () => {

//   return (
//     <>
//       <RouterProvider router={router} />
//     </>
//   )
// }
// export default App;
// -------------------------------------------------------------------


// const router = createBrowserRouter(
//   [
//     {
//       path: "/",
//       element: <div>Hello Sourav</div>
//     },
//     {
//       path: "/prouter",
//       element: <Prouter />
//     }
//   ]
// )
// const App = () => {
//   return (
//     <div>
//       <RouterProvider router={router} />
//     </div>
//   )
// }
// export default App;


// -----------------------------------


// //1st Question


// import React from "react";
// import ProductCard from "./components/ProductCard";

// const App: React.FC = () => {
//   return (
//     <div className="max-w-4xl mx-auto p-4">
//       <ProductCard
//         image="https://plus.unsplash.com/premium_photo-1661769750859-64b5f1539aa8?fm=jpg&q=60&w=3000&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZHVjdCUyMGltYWdlfGVufDB8fDB8fHww"
//         title="COWIN E7 Active"
//         newPrice={45.0}
//         oldPrice={95.45}
//         rating={4}
//         reviews={32}
//         description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa"
//       />
//       <ProductCard
//         image="https://cdn.shopify.com/s/files/1/2303/2711/files/2_e822dae0-14df-4cb8-b145-ea4dc0966b34.jpg?v=1617059123"
//         title="Apple iPhone XR"
//         newPrice={45.0}
//         oldPrice={95.45}
//         rating={4}
//         reviews={10}
//         description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus blandit massa"
//       />
//     </div>
//   );
// };

// export default App;

// --------------------------------------------------------------------

// 2nd question
// import ProductCard from "./components/ProductCard";


// function App() {
//   return (
//   <>
//   <ProductCard/>
//   </>
//   );
// }

// export default App;



// -------------------------------------------------------------------------------

//3rd


// import React from "react";
// import ProductCard from "./components/ProductCard";

// function App() {
//   let obj = {
//     image: "https://img.freepik.com/premium-psd/skincare-product-sale-poster-template_597316-411.jpg?semt=ais_hybrid&w=740 ",
//     bgcolor: "bg-pink-100",
//     bannertext1: "NEW ARRIVAL",
//     bannertext2: "Free Shipping",
//     bannertext3: "On Orders Above ₹999",
//     linkurl: "#"
//   }
//   let abc = {
//     image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRNpno25SxsKpUZH3MEwTkvFgUSs5nitvc8lTomlOJdeYXcGp0U7K_0RShCBq3A_hd3c-SJgFt5tDMfBJk2Yftlz_9GNAgKHjpB7v2RN5Q ",
//     bgcolor: "bg-pink-100",
//     bannertext1: "NEW ARRIVAL",
//     bannertext2: "Free Shipping",
//     bannertext3: "On Orders Above ₹999",
//     linkurl: "#"
//   }
//   return (
//     <div className="min-h-screen bg-gray-100 flex justify-center items-center ">
//       <ProductCard {...obj} />

//       <ProductCard {...abc} />
//     </div>
//   );
// }

// export default App


// -----------------------------------------------------



// 4th
// import ProductCard from "./components/ProductCard"
// const App = () => {
//   return (
//     <>
//       <ProductCard />
//     </>
//   )
// }
// export default App



// ----------------------------------------------

////Timer 



// import React from "react";
// import ProductCard from "./components/ProductCard";
// const App = () => {
//   return (
//     <>
//       <ProductCard />
//     </>
//   )
// }
// export default App;




// ------------------------------------------------------ 
//Form and store details



// import ProductCard from './components/ProductCard';

// function App() {
//     return (
//         <div className="bg-gray-100 min-h-screen">
//             <ProductCard />
//         </div>
//     );
// }
// export default App;