import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
// import Home from './components/Home'
// import CardLayout from './components/CardLayout'
// import FCCom from './components/FCCom'
// import ProfileCard from './components/ProfileCard'
// import HnadleEvents from './components/HnadleEvents'
// import LoginForm from './components/LoginForm'
// import ClassCom from './components/ClassCom'
// import UserList from './components/UserList'
import { Route,Routes,Link } from 'react-router-dom'
import FetchData from './components/miniApp/FetchData'
// import DynamicRoute from './components/DynamicRoute'
// import DynaIDCom from './components/DynaIDCom'

// import Home from './components/miniApp/Home'
// import Users from './components/miniApp/Users'
// import SearchUser from './components/miniApp/SearchUser'
// import ParticularUser from './components/miniApp/ParticularUser'

function App() {
  const [count, setCount] = useState(0)

  return (
  //   <div className="p-4">
  //   <nav className="space-x-4 mb-4">
  //     <Link to="/">Home</Link>
  //     <Link to="/CardLayout">CardLayout</Link>
  //     <Link to="/FCCom">FCCom</Link>
  //     <Link to="/ProfileCard">ProfileCard</Link>
  //     <Link to="/HnadleEvents">HnadleEvents</Link>
  //     <Link to="/LoginForm">LoginForm</Link>
  //     <Link to="/ClassCom">ClassCom</Link>
  //     <Link to="/UserList">UserList</Link>
  //     <Link to='/DynaminRoute'>DynaminRoute</Link>
  //   </nav>
  //   <Routes>
  //     <Route path="/" element={<Home />} />
  //     <Route path="/CardLayout" element={<CardLayout />} />
  //     <Route path="/FCCom" element={<FCCom />} />
  //     <Route path="/ProfileCard" element={<ProfileCard />} />
  //     <Route path="/HnadleEvents" element={<HnadleEvents />} />
  //     <Route path="/LoginForm" element={<LoginForm />} />
  //     <Route path="/ClassCom" element={<ClassCom />} />
  //     <Route path="/UserList" element={<UserList />} />
  //     <Route path="/DynaminRoute" element={<DynamicRoute />} />
  //     <Route path='/users/:id' element={<DynaIDCom />} />
  //   </Routes>
  // </div>
  ///// MINI APP
    //  <div className="min-h-screen bg-gray-50">
    //   <nav className="bg-gradient-to-r from-pink-500 via-red-400 to-yellow-400 text-white shadow-lg sticky top-0 z-50">
    //     <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
    //       <h1 className="text-2xl font-extrabold tracking-wide">🌸 AnimeVerse</h1>
    //       <div className="space-x-6 font-semibold">
    //         <Link
    //           to="/"
    //           className="hover:text-yellow-100 transition duration-200"
    //         >
    //           HomePage
    //         </Link>
    //         <Link
    //           to="/allusers"
    //           className="hover:text-yellow-100 transition duration-200"
    //         >
    //           All Users
    //         </Link>
    //         <Link
    //           to="/search"
    //           className="hover:text-yellow-100 transition duration-200"
    //         >
    //           Search User
    //         </Link>
    //       </div>
    //     </div>
    //   </nav>
    //  <Routes>
    //    <Route path='/' element={<Home />}/>
    //    <Route path='/allusers' element={<Users />}/>
    //    <Route path='/search' element={<SearchUser />}/>
    //    <Route path='/user/:id' element={<ParticularUser />}/>
    //  </Routes>
  // </div>
   <div>
    <FetchData />
   </div>
  )
}

export default App
