import React from 'react';

const Card = ({ title, description }) => (
  <div className="bg-white rounded-2xl shadow-md p-6">
    <h2 className="text-xl font-semibold mb-2">{title}</h2>
    <p className="text-gray-600 mb-4">{description}</p>
    <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition duration-300">
      Learn More
    </button>
  </div>
);

const CardLayout = () => {
  const cards = [
    {
      title: 'Card Title 1',
      description: 'This is a short description of the card content.',
    },
    {
      title: 'Card Title 2',
      description: 'This is a short description of the card content.',
    },
    {
      title: 'Card Title 3',
      description: 'This is a short description of the card content.',
    },
    {
      title: 'Card Title 4',
      description: 'This is a short description of the card content.',
    },
    {
        title: 'Card Title 5',
        description: 'This is a short description of the card content.',
      },
  ];

  return (
    <div className="bg-gray-100 min-h-screen p-6">
      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800">Responsive Card Layout</h1>
      </header>

      {/* Grid */}
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card, index) => (
          <Card key={index} title={card.title} description={card.description} />
        ))}
      </div>
    </div>
  );
};

export default CardLayout;
