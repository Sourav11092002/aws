import React,{FunctionComponent} from 'react'

const FCCom = () => {
  type functionalCom = {
    name: string;
    roll: number;
  }
  const FcFunction : FunctionComponent<functionalCom> = (props)=>{
     return(
      <div>
        <h1>{props.name}</h1>
        <h3>{props.roll}</h3>
      </div>
     )
  }
  return (
    <div>
      <h1>Functional Component</h1>
      <FcFunction name="John Doe" roll={123} />
    </div>
  )
}

export default FCCom

