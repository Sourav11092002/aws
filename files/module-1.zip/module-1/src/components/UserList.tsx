import React, { use } from 'react'

const UserList = () => {
  type user = {
    id: number;
    name: string;
    email: string;
  }
  const users: user[] =[
    {id:1,name:"sayak",email:"sayak456@gmail.com"},
    {id:2,name:"sam",email:"samu456@gmail.com"},
    {id:3,name:"ram",email:"ramuji456@gmail.com"}
  ]
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-100 py-10 px-4">
  <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl p-8">
    <h1 className="text-4xl font-bold text-center text-gray-800 mb-10 tracking-tight">
      👥 User List
    </h1>
    <ul className="space-y-6">
      {users.map((user) => (
        <li
          key={user.id}
          className="p-6 bg-gradient-to-r from-purple-200 to-indigo-200 rounded-2xl shadow-md hover:shadow-xl transition-shadow duration-300 transform hover:scale-[1.02]"
        >
          <h3 className="text-2xl font-semibold text-gray-800 mb-1">
            {user.name}
          </h3>
          <p className="text-gray-700 text-lg">{user.email}</p>
        </li>
      ))}
    </ul>
  </div>
</div>

  )
}

export default UserList
