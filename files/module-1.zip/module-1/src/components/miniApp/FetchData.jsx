import React, { useState, useEffect } from 'react';

const FetchData = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refresh,setRefresh] = useState(false)

  useEffect(() => {
    setLoading(true)
    fetch('https://dummyjson.com/products')
      .then((res) => res.json())
      .then((data) => {
        setData(data.products);
        setLoading(false);
      });
  }, [refresh]);

  const handleRefresh = ()=>{
    setRefresh(!refresh)
    // console.log(refresh)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-pink-100 to-purple-100 py-10 px-4">
      <h1 className="text-4xl font-bold text-center text-pink-600 mb-10 animate-pulse">
        🛍️ Style Product Showcase
      </h1>
     
      <div className="flex justify-center mb-6">
        <button
          onClick={handleRefresh}
          className="px-6 py-2 bg-pink-500 hover:bg-pink-600 text-white font-semibold rounded-full shadow-lg transition duration-300"
        >
          🔄 Refresh Products
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center min-h-[50vh]">
          <h1 className="text-2xl text-pink-500 font-semibold animate-bounce">
            Fetching data...
          </h1>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {data.map((item) => (
            <div
              key={item.id}
              className="bg-white border-2 border-pink-200 rounded-2xl shadow-xl p-6 hover:shadow-pink-400 transition-all duration-300 flex flex-col justify-between"
            >
              <img
                src={item.thumbnail}
                alt={item.title}
                className="rounded-xl mb-4 h-40 object-cover w-full shadow-md"
              />
              <h2 className="text-lg font-bold text-pink-600 mb-2">{item.title}</h2>
              <p className="text-sm text-gray-700 mb-4">{item.description}</p>
              <span className="text-md font-semibold text-purple-500">
                💲 {item.price}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FetchData;
