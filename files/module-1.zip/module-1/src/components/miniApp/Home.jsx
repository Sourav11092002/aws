import React from 'react';

const Home = () => {
  return (
    <div
      className="min-h-screen bg-cover bg-center flex items-center justify-center"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1612041887864-c9c2cb6a3e17?auto=format&fit=crop&w=1470&q=80')",
      }}
    >
      <div className="bg-black bg-opacity-60 backdrop-blur-sm p-10 rounded-3xl text-white text-center max-w-2xl shadow-2xl">
        <h1 className="text-5xl md:text-6xl font-extrabold mb-6 text-pink-400 drop-shadow-lg animate-pulse">
          🌸 Welcome to AnimeVerse
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mb-6">
          Dive into your favorite anime worlds. Stream episodes, explore characters, and relive legendary moments.
        </p>
        <button className="px-6 py-3 bg-pink-500 hover:bg-pink-600 text-white text-lg font-semibold rounded-full transition duration-300 shadow-lg hover:scale-105">
          Explore Now
        </button>
      </div>
    </div>
  );
};

export default Home;
