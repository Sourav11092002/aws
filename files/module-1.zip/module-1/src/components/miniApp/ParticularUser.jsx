import React from 'react';
import { useParams } from 'react-router-dom';

const ParticularUser = () => {
  const users = [
    {
      id: 1,
      name: "Satoru Gojo",
      email: "gojo@example.com",
      profilePhoto:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0DIfnIJb34lm7mYgKzTqIbWfhjNdqmRY52g&s",
    },
    {
      id: 2,
      name: "Naruto Uzumaki",
      email: "naruto@example.com",
      profilePhoto:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSy-0aFP8XsrVngwXgccZiCfu-4DphM1fmcA&s",
    },
    {
      id: 3,
      name: "Jinhwo Sung",
      email: "jinhwo@example.com",
      profilePhoto:
        "https://4kwallpapers.com/images/wallpapers/sung-jinwoo-solo-2048x2048-17972.jpg",
    },
    {
      id: 4,
      name: "Choi jong-in",
      email: "choi@example.com",
      profilePhoto:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPviQG09bj1pn98pKdo48NDKjM4w8dA7jkVA&s",
    },
  ];

  const { id } = useParams();
  const user = users.find((u) => u.id === Number(id));

  const UserComponent = ({ name, email, image }) => {
    return (
      <div className="bg-gradient-to-br from-pink-100 via-purple-100 to-yellow-50 min-h-screen flex items-center justify-center px-4 py-10">
        <div className="bg-white border-2 border-pink-200 shadow-2xl rounded-3xl max-w-md w-full p-8 text-center transform hover:scale-105 transition-all duration-300">
          <img
            src={image}
            alt={name}
            className="w-40 h-40 rounded-full mx-auto border-4 border-pink-300 shadow-lg mb-6 object-cover"
          />
          <h2 className="text-3xl font-extrabold text-pink-600">{name}</h2>
          <p className="text-gray-600 mt-2 text-lg">{email}</p>
          <p className="mt-4 text-sm text-gray-400 italic">
            ✨ Welcome to your personalized anime profile ✨
          </p>
        </div>
      </div>
    );
  };

  return (
    <div>
      {user ? (
        <UserComponent
          key={user.id}
          name={user.name}
          email={user.email}
          image={user.profilePhoto}
        />
      ) : (
        <div className="flex justify-center items-center h-screen text-2xl text-red-500 font-semibold">
          User not found 😢
        </div>
      )}
    </div>
  );
};

export default ParticularUser;
