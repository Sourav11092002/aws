import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const SearchUser = () => {
  const navigate = useNavigate();
  const [idValue, setIdValue] = useState('');

  const handleClick = () => {
    if (idValue.trim() !== '') {
      navigate(`/user/${idValue}`);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-100 via-yellow-50 to-white px-4">
      <div className="bg-white shadow-2xl rounded-3xl p-10 max-w-md w-full text-center border-2 border-pink-200">
        <h2 className="text-3xl font-bold text-pink-600 mb-6 animate-pulse">
          🔍 Search Anime User
        </h2>
        <input
          type="text"
          value={idValue}
          onChange={(e) => setIdValue(e.target.value)}
          placeholder="Enter User ID..."
          className="w-full px-4 py-3 mb-6 border-2 border-pink-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-400 shadow-sm text-lg transition"
        />
        <button
          onClick={handleClick}
          className="bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 rounded-full font-semibold text-lg transition-transform transform hover:scale-105 shadow-md"
        >
          Search ✨
        </button>
      </div>
    </div>
  );
};

export default SearchUser;
