import React from 'react';

const Users = () => {
  const users = [
    {
        id: 1,
        name: "Satoru Gojo",
        email: "gojo@example.com",
        profilePhoto:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0DIfnIJb34lm7mYgKzTqIbWfhjNdqmRY52g&s",
    },
    {
      id: 2,
      name: "Naruto Uzumaki",
      email: "naruto@example.com",
      profilePhoto:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSy-0aFP8XsrVngwXgccZiCfu-4DphM1fmcA&s",
    },
    {
      id: 3,
      name: "Jinhwo Sung",
      email: "jinhwo@example.com",
      profilePhoto:
        "https://4kwallpapers.com/images/wallpapers/sung-jinwoo-solo-2048x2048-17972.jpg",
    },
    {
      id: 4,
      name: "Choi jong-in",
      email: "choi@example.com",
      profilePhoto:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPviQG09bj1pn98pKdo48NDKjM4w8dA7jkVA&s",
    },
  ];

  const UserComponent = ({ name, email, image }) => {
    return (
      <div className="bg-white rounded-xl shadow-xl p-6 flex flex-col items-center text-center hover:scale-105 transition-transform duration-300">
        <img
          src={image}
          alt={name}
          className="w-32 h-32 rounded-full border-4 border-pink-300 shadow-md object-cover mb-4"
        />
        <h3 className="text-xl font-bold text-pink-600">{name}</h3>
        <p className="text-gray-600 text-sm mt-1">{email}</p>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-yellow-100 to-white py-10 px-6">
      <h2 className="text-4xl font-extrabold text-center text-pink-600 mb-10">🌸 All Anime Users</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
        {users.map((user) => (
          <UserComponent
            key={user.id}
            name={user.name}
            email={user.email}
            image={user.profilePhoto}
          />
        ))}
      </div>
    </div>
  );
};

export default Users;
