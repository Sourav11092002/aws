import React from 'react'

const HnadleEvents = () => {
    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        console.log("Button clicked!", e);
      };
    const handlweDoubleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        console.log("Button double clicked!", e);
    }
    
      return (
        <>
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded"
          onClick={handleClick}
        >
          Click Me
        </button>
        <button
          className="px-4 py-2 bg-blue-500 text-white rounded"
          onDoubleClick={handlweDoubleClick}
        >
          Click Me2
        </button>
        </>
      );
}

export default HnadleEvents
