import React from "react";

type Props = {
  name: string;
};

type State = {
  count: number;
};

class Welcome extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      count: 0,
    };
  }

  increment = () => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    return (
      <div className="p-4 bg-gray-100 rounded shadow">
        <h2 className="text-xl font-bold">Welcome, {this.props.name}</h2>
        <p>You've clicked {this.state.count} times</p>
        <button
          className="mt-2 px-4 py-2 bg-blue-500 text-white rounded"
          onClick={this.increment}
        >
          Click Me
        </button>
      </div>
    );
  }
}

export default Welcome