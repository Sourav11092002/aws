import React from 'react'

const Home = () => {
  return (
    <>
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
    <h1 className="text-4xl font-bold text-blue-600 mb-4">Welcome to Tailwind</h1>
    <p className="text-lg text-gray-700">This is your first Tailwind styled page.</p>
    <button className="mt-4 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg shadow-md">
      Click Me
    </button>
    <p className="text-sm sm:text-base md:text-lg lg:text-xl">
         This text grows on bigger screens.
    </p>
  </div>
  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
  <div className="bg-white p-4 rounded shadow">Card 1</div>
  <div className="bg-white p-4 rounded shadow">Card 2</div>
  <div className="bg-white p-4 rounded shadow">Card 3</div>
</div>
  
  </>
  )
}

export default Home
