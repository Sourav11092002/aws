import React from 'react'

const ProfileCard = () => {
    type props = {
        name : string;
        bio: string;
        age: number;
        img?: string;
    }
    const Profile: React.FC<props> = ({name,bio,age,img})=>{
      return(
        <div className='flex flex-row items-center justify-center border-2 border-black p-4 gap-4'>
          <h2>{name}</h2>
          <p>{bio}</p>
          <p>Age: {age}</p>
          {img ? <img src={img} alt={name} style={{width: '100px', height: '100px'}}/>: null}
        </div>
      )
    }
  return (
    <div >
      <Profile name="John Doe" bio="Software Engineer" age={30} />
      <Profile name="Sayak" bio="Software Developer" age={22} img='https://static.toiimg.com/thumb/msid-85617109,width-400,resizemode-4/85617109.jpg' />
    </div>
  )
}

export default ProfileCard
