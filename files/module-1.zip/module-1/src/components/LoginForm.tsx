import React,{useState} from 'react'

const LoginForm = () => {
    const [email, setEmail] = React.useState<string>('')
    // const [password,setPassword] = useState<String>('');
  const handleSubmit =(e: React.FormEvent<HTMLFormElement>)=>{
    e.preventDefault()
    console.log(`Email: ${email}`)
    console.log(`Password: ${e.currentTarget[1].value}`)
    // console.log(e)
  }
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder='example@gmail.com' />
        <input type="password" placeholder='Abc@123' />
        <button>Submit</button>
      </form>
    </div>
  )
}

export default LoginForm
