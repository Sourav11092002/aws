import React,{useState} from 'react';
import { useNavigate } from 'react-router-dom';

const UserProfile = () => {
//   const { id } = useParams();
//   const [id,setId] = useState<number>()
  const navigate = useNavigate()
  const handleClick= (e)=>{
   e.preventDefault();
   const id = e.currentTarget[0].value;
   console.log(id)
   navigate(`/users/${id}`)
  }
  return (
    <div className="p-4">
      <form onSubmit={handleClick}>
      <input type="text" placeholder='Enter your ID'/>
      <button>Click</button>
      </form>
    </div>
  );
};
export default UserProfile;